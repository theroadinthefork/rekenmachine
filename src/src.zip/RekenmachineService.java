public interface RekenmachineService {
    double output = 0;
    String solve(String current, String after, String operation);
    String solveAll(StringBuilder input);
    void showInput(String button);
}
