public interface RekenmachineService {
    String solveAll(StringBuilder input);
    void showInput(String button);
}
